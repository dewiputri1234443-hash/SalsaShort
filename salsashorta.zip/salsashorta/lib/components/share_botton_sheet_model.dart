import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'share_botton_sheet_widget.dart' show ShareBottonSheetWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ShareBottonSheetModel extends FlutterFlowModel<ShareBottonSheetWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading_uploadDataXyn = false;
  FFUploadedFile uploadedLocalFile_uploadDataXyn =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataXyn = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
