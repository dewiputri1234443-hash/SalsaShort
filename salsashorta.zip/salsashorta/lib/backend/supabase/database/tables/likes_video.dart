import '../database.dart';

class LikesVideoTable extends SupabaseTable<LikesVideoRow> {
  @override
  String get tableName => 'likes_video';

  @override
  LikesVideoRow createRow(Map<String, dynamic> data) => LikesVideoRow(data);
}

class LikesVideoRow extends SupabaseDataRow {
  LikesVideoRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => LikesVideoTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  String? get videoId => getField<String>('video_id');
  set videoId(String? value) => setField<String>('video_id', value);
}
