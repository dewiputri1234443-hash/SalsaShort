// Automatic FlutterFlow imports
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:zego_uikit_prebuilt_live_streaming/zego_uikit_prebuilt_live_streaming.dart';

class ZegoLiveWidget extends StatefulWidget {
  const ZegoLiveWidget({Key? key}) : super(key: key);

  @override
  State<ZegoLiveWidget> createState() => _ZegoLiveWidgetState();
}

class _ZegoLiveWidgetState extends State<ZegoLiveWidget> {
  final String userID = DateTime.now().millisecondsSinceEpoch.toString();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ZegoUIKitPrebuiltLiveStreaming(
        appID: 833726764, // AppID kamu
        appSign:
            "58ee406284f09372403a16cf386f4ae626fb6a312eda42366f17fa78d8368eb6", // AppSign kamu
        userID: userID,
        userName: "user_$userID",
        liveID: "room1", // bisa diganti bebas
        config: ZegoUIKitPrebuiltLiveStreamingConfig.host(),
      ),
    );
  }
}
