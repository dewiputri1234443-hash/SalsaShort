import '/backend/supabase/supabase.dart';
import '/components/share_teman_botton_sheet_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'profil_page_widget.dart' show ProfilPageWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfilPageModel extends FlutterFlowModel<ProfilPageWidget> {
  ///  State fields for stateful widgets in this page.

  Stream<List<ProfilesRow>>? profilPageSupabaseStream;
  bool isDataUploading_uploadDataOmv = false;
  FFUploadedFile uploadedLocalFile_uploadDataOmv =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataOmv = '';

  bool isDataUploading_uploadDataB1t = false;
  FFUploadedFile uploadedLocalFile_uploadDataB1t =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataB1t = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
