import '/backend/supabase/supabase.dart';
import '/components/share_teman_botton_sheet_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'profil_like_page_widget.dart' show ProfilLikePageWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfilLikePageModel extends FlutterFlowModel<ProfilLikePageWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadDataBze = false;
  FFUploadedFile uploadedLocalFile_uploadDataBze =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataBze = '';

  bool isDataUploading_uploadDataFld = false;
  FFUploadedFile uploadedLocalFile_uploadDataFld =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataFld = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
