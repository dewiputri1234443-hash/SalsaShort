import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'edit_profil_page_widget.dart' show EditProfilPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditProfilPageModel extends FlutterFlowModel<EditProfilPageWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadData6pn = false;
  FFUploadedFile uploadedLocalFile_uploadData6pn =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadData6pn = '';

  bool isDataUploading_uploadDataS5h = false;
  FFUploadedFile uploadedLocalFile_uploadDataS5h =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataS5h = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
