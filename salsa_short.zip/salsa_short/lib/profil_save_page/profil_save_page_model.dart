import '/backend/supabase/supabase.dart';
import '/components/share_teman_botton_sheet_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'profil_save_page_widget.dart' show ProfilSavePageWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfilSavePageModel extends FlutterFlowModel<ProfilSavePageWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadData66z = false;
  FFUploadedFile uploadedLocalFile_uploadData66z =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadData66z = '';

  bool isDataUploading_uploadDataCq3 = false;
  FFUploadedFile uploadedLocalFile_uploadDataCq3 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataCq3 = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
