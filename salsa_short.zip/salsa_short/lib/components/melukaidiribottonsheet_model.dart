import '/backend/supabase/supabase.dart';
import '/components/sukses_botton_sheet_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'melukaidiribottonsheet_widget.dart' show MelukaidiribottonsheetWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MelukaidiribottonsheetModel
    extends FlutterFlowModel<MelukaidiribottonsheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
