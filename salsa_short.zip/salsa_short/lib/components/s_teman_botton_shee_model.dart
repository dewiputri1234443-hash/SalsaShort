import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/cartemani_bootton_sheet_widget.dart';
import '/components/kirim_button_sheet_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 's_teman_botton_shee_widget.dart' show STemanBottonSheeWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

class STemanBottonSheeModel extends FlutterFlowModel<STemanBottonSheeWidget> {
  ///  State fields for stateful widgets in this component.

  Stream<List<ProfilesRow>>? listViewSupabaseStream;
  // State field(s) for Checkbox widget.
  Map<ProfilesRow, bool> checkboxValueMap = {};
  List<ProfilesRow> get checkboxCheckedItems =>
      checkboxValueMap.entries.where((e) => e.value).map((e) => e.key).toList();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
