import '../database.dart';

class UserSettingTable extends SupabaseTable<UserSettingRow> {
  @override
  String get tableName => 'user_setting';

  @override
  UserSettingRow createRow(Map<String, dynamic> data) => UserSettingRow(data);
}

class UserSettingRow extends SupabaseDataRow {
  UserSettingRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UserSettingTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  bool? get isPrivate => getField<bool>('is_private');
  set isPrivate(bool? value) => setField<bool>('is_private', value);

  bool? get allowDowload => getField<bool>('allow_dowload');
  set allowDowload(bool? value) => setField<bool>('allow_dowload', value);

  bool? get allowComments => getField<bool>('allow_comments');
  set allowComments(bool? value) => setField<bool>('allow_comments', value);

  bool? get darkMode => getField<bool>('dark_mode');
  set darkMode(bool? value) => setField<bool>('dark_mode', value);

  bool? get notifLike => getField<bool>('notif_like');
  set notifLike(bool? value) => setField<bool>('notif_like', value);

  bool? get notifFollow => getField<bool>('notif_follow');
  set notifFollow(bool? value) => setField<bool>('notif_follow', value);

  bool? get notifComment => getField<bool>('notif_comment');
  set notifComment(bool? value) => setField<bool>('notif_comment', value);

  bool? get notifRepost => getField<bool>('notif_repost');
  set notifRepost(bool? value) => setField<bool>('notif_repost', value);

  bool? get is18Plus => getField<bool>('is_18_plus');
  set is18Plus(bool? value) => setField<bool>('is_18_plus', value);

  bool? get allowFollow => getField<bool>('allow_follow');
  set allowFollow(bool? value) => setField<bool>('allow_follow', value);

  bool? get allowLike => getField<bool>('allow_like');
  set allowLike(bool? value) => setField<bool>('allow_like', value);

  bool? get allowFavorite => getField<bool>('allow_favorite');
  set allowFavorite(bool? value) => setField<bool>('allow_favorite', value);
}
