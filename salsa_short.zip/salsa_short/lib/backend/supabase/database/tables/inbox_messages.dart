import '../database.dart';

class InboxMessagesTable extends SupabaseTable<InboxMessagesRow> {
  @override
  String get tableName => 'inbox_messages';

  @override
  InboxMessagesRow createRow(Map<String, dynamic> data) =>
      InboxMessagesRow(data);
}

class InboxMessagesRow extends SupabaseDataRow {
  InboxMessagesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => InboxMessagesTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get senderId => getField<String>('sender_id');
  set senderId(String? value) => setField<String>('sender_id', value);

  String? get receiverId => getField<String>('receiver_id');
  set receiverId(String? value) => setField<String>('receiver_id', value);

  String? get videoId => getField<String>('video_id');
  set videoId(String? value) => setField<String>('video_id', value);

  String? get message => getField<String>('message');
  set message(String? value) => setField<String>('message', value);
}
