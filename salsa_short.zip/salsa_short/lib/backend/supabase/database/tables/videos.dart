import '../database.dart';

class VideosTable extends SupabaseTable<VideosRow> {
  @override
  String get tableName => 'videos';

  @override
  VideosRow createRow(Map<String, dynamic> data) => VideosRow(data);
}

class VideosRow extends SupabaseDataRow {
  VideosRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => VideosTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  String? get videoUrl => getField<String>('video_url');
  set videoUrl(String? value) => setField<String>('video_url', value);

  String? get caption => getField<String>('caption');
  set caption(String? value) => setField<String>('caption', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get username => getField<String>('username');
  set username(String? value) => setField<String>('username', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get audioId => getField<String>('audio_id');
  set audioId(String? value) => setField<String>('audio_id', value);

  String? get audioCoverUrl => getField<String>('audio_cover_url');
  set audioCoverUrl(String? value) =>
      setField<String>('audio_cover_url', value);

  String? get avatarUrl => getField<String>('avatar_url');
  set avatarUrl(String? value) => setField<String>('avatar_url', value);

  bool? get isPublic => getField<bool>('is_public');
  set isPublic(bool? value) => setField<bool>('is_public', value);

  bool? get allowRepost => getField<bool>('allow_repost');
  set allowRepost(bool? value) => setField<bool>('allow_repost', value);

  int? get repostCount => getField<int>('repost_count');
  set repostCount(int? value) => setField<int>('repost_count', value);

  bool? get allowDownload => getField<bool>('allow_download');
  set allowDownload(bool? value) => setField<bool>('allow_download', value);

  String? get followingId => getField<String>('following_id');
  set followingId(String? value) => setField<String>('following_id', value);
}
