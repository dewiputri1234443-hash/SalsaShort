import '../database.dart';

class ContentSharesTable extends SupabaseTable<ContentSharesRow> {
  @override
  String get tableName => 'content_shares';

  @override
  ContentSharesRow createRow(Map<String, dynamic> data) =>
      ContentSharesRow(data);
}

class ContentSharesRow extends SupabaseDataRow {
  ContentSharesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ContentSharesTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get contentId => getField<String>('content_id');
  set contentId(String? value) => setField<String>('content_id', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  String? get platform => getField<String>('platform');
  set platform(String? value) => setField<String>('platform', value);

  String? get fromUserId => getField<String>('from_user_id');
  set fromUserId(String? value) => setField<String>('from_user_id', value);

  String? get toUserId => getField<String>('to_user_id');
  set toUserId(String? value) => setField<String>('to_user_id', value);
}
