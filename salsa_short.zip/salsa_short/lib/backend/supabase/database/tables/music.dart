import '../database.dart';

class MusicTable extends SupabaseTable<MusicRow> {
  @override
  String get tableName => 'music';

  @override
  MusicRow createRow(Map<String, dynamic> data) => MusicRow(data);
}

class MusicRow extends SupabaseDataRow {
  MusicRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => MusicTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  String? get title => getField<String>('title');
  set title(String? value) => setField<String>('title', value);

  String? get coverUrl => getField<String>('cover_url');
  set coverUrl(String? value) => setField<String>('cover_url', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  bool? get isPublic => getField<bool>('is_public');
  set isPublic(bool? value) => setField<bool>('is_public', value);

  String? get albumId => getField<String>('album_id');
  set albumId(String? value) => setField<String>('album_id', value);

  String? get audioUrl => getField<String>('audio_url');
  set audioUrl(String? value) => setField<String>('audio_url', value);

  int? get duration => getField<int>('duration');
  set duration(int? value) => setField<int>('duration', value);

  int? get plays => getField<int>('plays');
  set plays(int? value) => setField<int>('plays', value);
}
