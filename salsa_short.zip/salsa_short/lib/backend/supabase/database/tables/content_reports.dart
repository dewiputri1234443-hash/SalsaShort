import '../database.dart';

class ContentReportsTable extends SupabaseTable<ContentReportsRow> {
  @override
  String get tableName => 'content_reports';

  @override
  ContentReportsRow createRow(Map<String, dynamic> data) =>
      ContentReportsRow(data);
}

class ContentReportsRow extends SupabaseDataRow {
  ContentReportsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ContentReportsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get contentType => getField<String>('content_type');
  set contentType(String? value) => setField<String>('content_type', value);

  String? get contentId => getField<String>('content_id');
  set contentId(String? value) => setField<String>('content_id', value);

  String get reportReason => getField<String>('report_reason')!;
  set reportReason(String value) => setField<String>('report_reason', value);

  String? get reporterUserId => getField<String>('reporter_user_id');
  set reporterUserId(String? value) =>
      setField<String>('reporter_user_id', value);

  String? get reportDetail => getField<String>('report_detail');
  set reportDetail(String? value) => setField<String>('report_detail', value);
}
