import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['id', 'en'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? idText = '',
    String? enText = '',
  }) =>
      [idText, enText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    '89by2bgj': {
      'id': 'username',
      'en': '',
    },
    'kw31rsft': {
      'id': 'Ikuti',
      'en': '',
    },
    'jgxby2kx': {
      'id': 'deskripsi',
      'en': '',
    },
    'clbburox': {
      'id': 'Jelajahi',
      'en': '',
    },
    'rmy3qdgy': {
      'id': 'Mengikuti',
      'en': '',
    },
    '46y5raxm': {
      'id': 'Teman',
      'en': '',
    },
    'jpiswwf4': {
      'id': 'Beranda',
      'en': '',
    },
    '0i9jb9xl': {
      'id': 'Profil',
      'en': '',
    },
    'wriganoa': {
      'id': 'Home',
      'en': 'home',
    },
  },
  // EditProfilPage
  {
    'po4g33z4': {
      'id': 'Ubah Foto',
      'en': '',
    },
    'edjywlru': {
      'id': 'nama',
      'en': '',
    },
    'fup3phou': {
      'id': 'nama Pengguna',
      'en': '',
    },
    'b54qik7g': {
      'id': 'bio',
      'en': '',
    },
    '27o2f3nz': {
      'id': 'Edit Profil',
      'en': '',
    },
    'nwyo2qyb': {
      'id': 'Home',
      'en': '',
    },
  },
  // DetilProfilPage
  {
    'unclzu1t': {
      'id': 'Batal',
      'en': '',
    },
    '7zq5zd5c': {
      'id': 'Simpan',
      'en': '',
    },
    '8mg8w23j': {
      'id': 'Nama',
      'en': '',
    },
    'p43b930e': {
      'id': 'Silahkan Isi Nama Di Bawah ini',
      'en': '',
    },
    'd5xlp9v3': {
      'id': 'Nama Pengguna',
      'en': '',
    },
    'zriche8s': {
      'id': 'Home',
      'en': '',
    },
  },
  // Detil_NamaProfilPage
  {
    'gfao6g39': {
      'id': 'Batal',
      'en': '',
    },
    '8fx96y19': {
      'id': 'Simpan',
      'en': '',
    },
    'dco57nx1': {
      'id': 'Nama Pengguna',
      'en': '',
    },
    'vkbpnb7e': {
      'id': 'Silahkan isi Nama di Bawah ini',
      'en': '',
    },
    'yzqihyms': {
      'id': 'Ketik Nama',
      'en': '',
    },
    '65kicov2': {
      'id': 'Home',
      'en': '',
    },
  },
  // Profil_BioPage
  {
    '29nqca8h': {
      'id': 'Batal',
      'en': '',
    },
    'my8wyw8e': {
      'id': 'Simpan',
      'en': '',
    },
    '6t4gqb37': {
      'id': 'Bio',
      'en': '',
    },
    'u2yji4m5': {
      'id': 'Silahkan isi Bio Di bawah ini',
      'en': '',
    },
    'ha4lz0xv': {
      'id': 'Ketik Bio',
      'en': '',
    },
    '8yj1t3oi': {
      'id': '0/ 200',
      'en': '',
    },
    'v883iqm7': {
      'id': 'Home',
      'en': '',
    },
  },
  // SearchPage
  {
    'qcdbyqu6': {
      'id': 'Search',
      'en': '',
    },
    'o5uielx3': {
      'id': 'cari',
      'en': '',
    },
    '8p8dqvfa': {
      'id': 'Hasil Pencarian',
      'en': '',
    },
    '1f9ejesf': {
      'id': 'Lihat Lainnya',
      'en': '',
    },
    'jgm65xga': {
      'id': 'Mungkin Anda Suka',
      'en': '',
    },
    'g7iayldf': {
      'id': 'Home',
      'en': '',
    },
  },
  // ResulSearchPage
  {
    '705nxsmg': {
      'id': 'Search',
      'en': '',
    },
    'p7d4v7ut': {
      'id': 'Cari',
      'en': '',
    },
    'xurmlw8o': {
      'id': 'Teratas',
      'en': '',
    },
    'zrp7fosc': {
      'id': 'Video',
      'en': '',
    },
    'i3exyp2f': {
      'id': 'Foto',
      'en': '',
    },
    'oy3t9jna': {
      'id': 'Pengguna',
      'en': '',
    },
    'k5epgn0r': {
      'id': 'Home',
      'en': '',
    },
  },
  // AploadPage
  {
    'c41rey52': {
      'id': 'Buat Postingan',
      'en': '',
    },
    '5zic59mt': {
      'id': 'Pilih Dari Galery',
      'en': '',
    },
    '661hyrc1': {
      'id': 'Home',
      'en': '',
    },
  },
  // LoginPage
  {
    'zp5n1wkp': {
      'id': 'Masuk',
      'en': '',
    },
    '0r1cn94i': {
      'id': 'Ketik Untuk Masuk',
      'en': '',
    },
    '6wmxh3j1': {
      'id': 'Email',
      'en': '',
    },
    'qqtauno6': {
      'id': 'Password',
      'en': '',
    },
    '0vgpjcb4': {
      'id': 'Masuk',
      'en': '',
    },
    '4ufajotb': {
      'id': 'Lupa Password',
      'en': '',
    },
    '7g990i5g': {
      'id': 'Pilih Untuk Masuk',
      'en': '',
    },
    'ntmrs1de': {
      'id': 'Menggunakan Google',
      'en': '',
    },
    'qhso5jvn': {
      'id': 'Menggunakan Nomor',
      'en': '',
    },
    '3kgc24zl': {
      'id': 'Daftar',
      'en': '',
    },
    'ivjj3nqw': {
      'id': 'Silahkan Mendaftar',
      'en': '',
    },
    'aw0818me': {
      'id': 'Email',
      'en': '',
    },
    'qrlytt8a': {
      'id': 'Password',
      'en': '',
    },
    'vstd1gnc': {
      'id': 'Confirm Password',
      'en': '',
    },
    'clarsda1': {
      'id': 'Daftar Akun',
      'en': '',
    },
    'c7oecoyz': {
      'id': 'Pilihan Untuk Masuk',
      'en': '',
    },
    'njiusg4r': {
      'id': 'Menggunakan Google',
      'en': '',
    },
    'yl81jkt1': {
      'id': 'Menggunakan Nomor',
      'en': '',
    },
    'pcu9ones': {
      'id': 'Home',
      'en': '',
    },
  },
  // InbokPage
  {
    'dod9o0su': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    'g6wi5ma9': {
      'id': 'Upload',
      'en': '',
    },
    '05076u3r': {
      'id': 'Aktivitas',
      'en': '',
    },
    'p6q3bu50': {
      'id': 'deskripsi',
      'en': '',
    },
    'om0qif2h': {
      'id': 'Notifikasi',
      'en': '',
    },
    'shltkspa': {
      'id': 'deskripsi',
      'en': '',
    },
    'wjlu9bm9': {
      'id': 'Notifikasi',
      'en': '',
    },
    'vqfqnvzl': {
      'id': 'deskripsi',
      'en': '',
    },
    'nmk0fwv3': {
      'id': 'username',
      'en': '',
    },
    'y5t0xj27': {
      'id': 'Pesan terakhir',
      'en': '',
    },
    'ux98yudk': {
      'id': 'Beranda',
      'en': '',
    },
    'objfw4xm': {
      'id': 'Profil',
      'en': '',
    },
    'iry0h6iv': {
      'id': 'Kotak Masuk',
      'en': '',
    },
  },
  // User_SettingPage
  {
    'kulaekcy': {
      'id': 'Pengaturan dan Privasi',
      'en': '',
    },
    '4a5i9d6i': {
      'id': 'Akun',
      'en': '',
    },
    'huwk78wh': {
      'id': 'Privasi',
      'en': '',
    },
    '22lzy06x': {
      'id': 'Konten Tampilan',
      'en': '',
    },
    'kg9e994q': {
      'id': 'Notifikasi',
      'en': '',
    },
    '04208jxw': {
      'id': 'Kontrol  Penonton',
      'en': '',
    },
    'ivqayhoi': {
      'id': 'Bahasa',
      'en': '',
    },
    'qikppizd': {
      'id': 'Pusat Bantuan',
      'en': '',
    },
    'im7kmi6s': {
      'id': 'Ketentuan dan kebijakan',
      'en': '',
    },
    '0lanzgqq': {
      'id': 'kELUAR',
      'en': '',
    },
    'wvxk0yd3': {
      'id': 'Home',
      'en': '',
    },
  },
  // Ketentuan_SettingPage
  {
    'ktkdudut': {
      'id': 'Ketentuan dan Kebijakan',
      'en': '',
    },
    'qtdrketn': {
      'id': 'Panduan Komunitas',
      'en': '',
    },
    'dmxp9dmy': {
      'id': 'Ketentuan Layanan',
      'en': '',
    },
    'ayukof24': {
      'id': 'Kebijakan Privasi',
      'en': '',
    },
    '2cbbvse5': {
      'id': 'Home',
      'en': '',
    },
  },
  // PanduanKomunitasPage
  {
    'yt7n49to': {
      'id': 'Panduan Komunitas',
      'en': '',
    },
    '8my56fx1': {
      'id': 'SalsaShortApp',
      'en': '',
    },
    'wr3ff3go': {
      'id': 'Panduan Komunitas',
      'en': '',
    },
    'gv7h542y': {
      'id':
          'Platform ini dibuat untuk berbagi kreativitas, berinteraksi secara positif, dan membangun komunitas yang aman.\nPengguna diwajibkan menghormati sesama, tidak menyebarkan konten berbahaya, dan mematuhi aturan yang berlaku demi kenyamanan bersama.',
      'en': '',
    },
    'tg7cfey6': {
      'id': 'Home',
      'en': '',
    },
  },
  // Ketentua_LayananPage
  {
    'j9wemfvl': {
      'id': 'Ketentuan Layanan ! SalsaShortApp',
      'en': '',
    },
    'opx0849e': {
      'id':
          'Dengan menggunakan aplikasi ini, Anda setuju untuk mematuhi seluruh ketentuan yang berlaku. Layanan disediakan sebagaimana adanya dan dapat diperbarui sewaktu-waktu. Pengguna bertanggung jawab atas aktivitas dan konten yang dibagikan. Pelanggaran dapat mengakibatkan pembatasan atau penonaktifan akun.',
      'en': '',
    },
    'j1i3cyiq': {
      'id': 'Home',
      'en': '',
    },
  },
  // PengikutPage
  {
    'qcxg18jh': {
      'id': 'Mengikuti',
      'en': '',
    },
    '9ifbe00p': {
      'id': '0',
      'en': '',
    },
    'auo8awi4': {
      'id': 'Pengikut',
      'en': '',
    },
    'ek848t4a': {
      'id': '0',
      'en': '',
    },
    'rm6hfpat': {
      'id': 'Teman',
      'en': '',
    },
    'm5yxr91u': {
      'id': '0',
      'en': '',
    },
    'bi0xq3qe': {
      'id': 'Search',
      'en': '',
    },
    'd5xnhl22': {
      'id': 'cari',
      'en': '',
    },
    'sa8077nc': {
      'id': 'Teman',
      'en': '',
    },
    'i8gpzo3v': {
      'id': 'Home',
      'en': '',
    },
  },
  // PrivasiPage
  {
    'z5y6rb41': {
      'id': 'Privasi',
      'en': '',
    },
    'o10ewf6i': {
      'id': 'Akun Privasi',
      'en': '',
    },
    '19ufrhqs': {
      'id':
          'Saat akun privat aktif, hanya pengikut yang disetujui yang dapat melihat video dan aktivitas Anda. Pengikut lama tetap bisa mengakses akun Anda seperti biasa.',
      'en': '',
    },
    'wbwj0py8': {
      'id': 'Status Aktivitas',
      'en': '',
    },
    '3e04y4mn': {
      'id':
          'Saat diaktifkan, Anda dan teman Anda (pengikut yang saling mengikuti) dapat melihat status aktivitas satu sama lain. Status ini hanya terlihat jika kedua pihak mengaktifkan pengaturan ini.Saat diaktifkan, Anda dan teman Anda (pengikut yang saling mengikuti) dapat melihat status aktivitas satu sama lain. Status ini hanya terlihat jika kedua pihak mengaktifkan pengaturan ini.Saat diaktifkan, Anda dan teman Anda (pengikut yang saling mengikuti) dapat melihat status aktivitas satu sama lain. Status ini hanya terlihat jika kedua pihak mengaktifkan pengaturan ini.',
      'en': '',
    },
    'ovo69122': {
      'id': 'Intraksi',
      'en': '',
    },
    'n7zvzjgy': {
      'id': 'Home',
      'en': '',
    },
  },
  // InteraksiPage
  {
    'v0nfvt3q': {
      'id': 'Interaksi',
      'en': '',
    },
    'geh09qod': {
      'id': 'komentar',
      'en': '',
    },
    'zn4v6bdj': {
      'id': 'Unduhan',
      'en': '',
    },
    '2lnsw053': {
      'id': 'Mengikuti',
      'en': '',
    },
    'ixmxv2he': {
      'id': 'Video Disukai',
      'en': '',
    },
    '3m4nd42p': {
      'id': 'favorit',
      'en': '',
    },
    'o0ntazun': {
      'id': 'Home',
      'en': '',
    },
  },
  // NotifikasiPage
  {
    'rwkbpn4j': {
      'id': 'Notifikasi',
      'en': '',
    },
    'xcq43kz9': {
      'id': 'Suka',
      'en': '',
    },
    'qufnw9j4': {
      'id': 'Komentar',
      'en': '',
    },
    'kwwb8n6x': {
      'id': 'Pengikut Baru',
      'en': '',
    },
    '8lm98u05': {
      'id': 'Posting Ulang',
      'en': '',
    },
    'c482edm5': {
      'id': 'Home',
      'en': '',
    },
  },
  // KontrolPenontonPage
  {
    '3z7ft6i7': {
      'id': 'Kontrol Penonton',
      'en': '',
    },
    'l5js018c': {
      'id': 'Berusia 18 Ke Atas',
      'en': '',
    },
    'd677rfzo': {
      'id':
          'Berusia 18 tahun ke atas\nBatasi profil dan video agar hanya dapat ditonton oleh penonton berusia 18 tahun ke atas. Pengaturan ini berlaku untuk seluruh konten video dan tidak dapat diubah per video.',
      'en': '',
    },
    '83ecz4c9': {
      'id': 'Home',
      'en': '',
    },
  },
  // KebijakanPrivasiPage
  {
    'e9pmdaeo': {
      'id': 'Kebijakan Privasi',
      'en': '',
    },
    '3hfrwa53': {
      'id': 'Kebijakan Privasi\nTerakhir diperbarui: 2026',
      'en': '',
    },
    '6o33y4q2': {
      'id':
          'Kami menghargai privasi Anda. Informasi pengguna dikumpulkan dan digunakan hanya untuk menyediakan serta meningkatkan layanan. Data disimpan dengan aman dan tidak dibagikan kepada pihak ketiga tanpa izin, kecuali diwajibkan oleh hukum. Dengan menggunakan aplikasi ini, Anda menyetujui kebijakan privasi ini.',
      'en': '',
    },
    'p8d1n2e5': {
      'id': 'Home',
      'en': '',
    },
  },
  // AkunPage
  {
    'usao6bdv': {
      'id': 'Akun',
      'en': '',
    },
    'he643zzr': {
      'id': 'Informasi Akun',
      'en': '',
    },
    '3j164nnz': {
      'id': 'Kata Sandi',
      'en': '',
    },
    'v3okjgel': {
      'id': 'Home',
      'en': '',
    },
  },
  // InformasiAkunPage
  {
    'tv4mw2oe': {
      'id': 'Informasi Akun',
      'en': '',
    },
    'q5seexoz': {
      'id': 'Email',
      'en': '',
    },
    '3tqd8v1c': {
      'id': 'Home',
      'en': '',
    },
  },
  // EmailPage
  {
    'gxlm1yim': {
      'id': 'Tambahkan Email',
      'en': '',
    },
    '0nribwi2': {
      'id': 'Masukkan Email',
      'en': '',
    },
    '2iqpb6a9': {
      'id': 'Simpan',
      'en': '',
    },
    'mk0e6a8c': {
      'id': 'Home',
      'en': '',
    },
  },
  // KataSandiPage
  {
    'usv0beuw': {
      'id': 'Buat Kata Sandi',
      'en': '',
    },
    'vbhguxvj': {
      'id': 'Masukkan Kata Sandi',
      'en': '',
    },
    '75bi321q': {
      'id':
          'Minimal 8 karakter (maks. 20)\n• Mengandung huruf, angka, dan simbol\n• Contoh simbol: # ? ! @\n• Kata sandi harus kuat',
      'en': '',
    },
    'zvb6u1u0': {
      'id': 'Simpan',
      'en': '',
    },
    'gnqxrr5c': {
      'id': 'Home',
      'en': '',
    },
  },
  // BahasaPage
  {
    '5kgn01ne': {
      'id': 'Bahasa',
      'en': '',
    },
    '6x7jvqi9': {
      'id': 'Indonesia',
      'en': '',
    },
    'ijp2epzy': {
      'id': 'Inggris',
      'en': '',
    },
    'y3besflx': {
      'id': 'Home',
      'en': '',
    },
  },
  // ResulSearch_P0hotoPage
  {
    'ciijhn36': {
      'id': 'Search',
      'en': '',
    },
    'nqqn29hy': {
      'id': 'Cari',
      'en': '',
    },
    '5emr7jyl': {
      'id': 'Teratas',
      'en': '',
    },
    'xktzlbwj': {
      'id': 'Video',
      'en': '',
    },
    'p8tn0fdq': {
      'id': 'Foto',
      'en': '',
    },
    'nxgy9l33': {
      'id': 'Pengguna',
      'en': '',
    },
    'l80hjfcj': {
      'id': 'Home',
      'en': '',
    },
  },
  // ResulSearch_TeratasPage
  {
    'ow2dfpi8': {
      'id': 'Search',
      'en': '',
    },
    'j3rfcvhn': {
      'id': 'Option 1',
      'en': '',
    },
    '3rc4cth9': {
      'id': 'Cari',
      'en': '',
    },
    'd8w2thuk': {
      'id': 'Teratas',
      'en': '',
    },
    'kj4ad7hu': {
      'id': 'Video',
      'en': '',
    },
    'jkxsd7vc': {
      'id': 'Foto',
      'en': '',
    },
    'fypl8stm': {
      'id': 'Pengguna',
      'en': '',
    },
    'e58tarfk': {
      'id': 'Home',
      'en': '',
    },
  },
  // ResulSearch_PenggunaPage
  {
    '7jvf0tc2': {
      'id': 'Search',
      'en': '',
    },
    'uzdd11sr': {
      'id': 'Cari',
      'en': '',
    },
    'xn9gzj7s': {
      'id': 'Teratas',
      'en': '',
    },
    'zwzlwo0q': {
      'id': 'Video',
      'en': '',
    },
    'l3xeniuy': {
      'id': 'Foto',
      'en': '',
    },
    '94mm3wc6': {
      'id': 'Pengguna',
      'en': '',
    },
    '88paqivh': {
      'id': 'Home',
      'en': '',
    },
  },
  // Audio_VideoPage
  {
    'yg600buf': {
      'id': 'Ikuti',
      'en': 'following',
    },
    'jqeypot4': {
      'id': 'Gunakan Suara',
      'en': '',
    },
    'qpezei19': {
      'id': 'cari konten terkait',
      'en': '',
    },
    'v7qklxdp': {
      'id': 'Home',
      'en': 'home',
    },
  },
  // Chat_inbokPage
  {
    'rzi8plx1': {
      'id': 'username',
      'en': '',
    },
    'abofnyzx': {
      'id': 'waktu',
      'en': '',
    },
    'p3myndno': {
      'id': 'Tulis Pesan',
      'en': '',
    },
    'hgiumxiz': {
      'id': 'Home',
      'en': '',
    },
  },
  // MengikutPage
  {
    'gxmqtkpu': {
      'id': 'Mengikuti',
      'en': '',
    },
    '0570zvp7': {
      'id': '0',
      'en': '',
    },
    'axs30s25': {
      'id': 'Pengikut',
      'en': '',
    },
    'fath9yg1': {
      'id': '0',
      'en': '',
    },
    'ubzzktrk': {
      'id': 'Teman',
      'en': '',
    },
    'rusvvkrj': {
      'id': '0',
      'en': '',
    },
    'yj4spq63': {
      'id': 'Search',
      'en': '',
    },
    '5h0wdfk0': {
      'id': 'cari',
      'en': '',
    },
    'dxxn6yyc': {
      'id': 'Mengikuti',
      'en': '',
    },
    'g3gzrzs3': {
      'id': 'Home',
      'en': '',
    },
  },
  // TemanPage
  {
    'esdawqnw': {
      'id': 'Mengikuti',
      'en': '',
    },
    'yxjsleei': {
      'id': '0',
      'en': '',
    },
    'pgwgrdtu': {
      'id': 'Pengikut',
      'en': '',
    },
    'lkxt8788': {
      'id': '0',
      'en': '',
    },
    'ev5w83x3': {
      'id': 'Teman',
      'en': '',
    },
    '40h5kn7o': {
      'id': '0',
      'en': '',
    },
    '255zu99p': {
      'id': 'Search',
      'en': '',
    },
    'btvtbwyd': {
      'id': 'cari',
      'en': '',
    },
    'oyscs9dk': {
      'id': 'Pesan',
      'en': '',
    },
    'oyiyfsw7': {
      'id': 'Home',
      'en': '',
    },
  },
  // Cari_TemanPage
  {
    'ngp1niyz': {
      'id': 'Cari Teman',
      'en': '',
    },
    'n6nb9orb': {
      'id': 'Search',
      'en': '',
    },
    '9s1b6c8o': {
      'id': 'cari',
      'en': '',
    },
    '3l2j29cs': {
      'id': 'username',
      'en': '',
    },
    'szue1ok6': {
      'id': 'Bio',
      'en': '',
    },
    'xxer9vdi': {
      'id': 'Ikuti',
      'en': '',
    },
    'zzaqtn91': {
      'id': 'Home',
      'en': '',
    },
  },
  // Suara_soudPage
  {
    'gkn2yssp': {
      'id': 'Cari Konten Yang mirip',
      'en': '',
    },
    'w5kfkv2r': {
      'id': 'Suara Asli',
      'en': '',
    },
    'uix3fhfz': {
      'id': 'Judul',
      'en': '',
    },
    'jnbd3c4b': {
      'id': 'Gabung',
      'en': '',
    },
    'n51erz2d': {
      'id': 'Ikuti',
      'en': '',
    },
    '9hg0whzt': {
      'id': 'Tambah ke Favorit',
      'en': '',
    },
    'qyusb3uw': {
      'id': 'Gunakan Suara',
      'en': '',
    },
    'vwy3gw7t': {
      'id': 'Home',
      'en': '',
    },
  },
  // HomeTeamanPage
  {
    'hgdd5fid': {
      'id': 'Ikuti',
      'en': '',
    },
    '1cojyyzv': {
      'id': 'Jelajahi',
      'en': '',
    },
    '8tljmchg': {
      'id': 'Mengikuti',
      'en': '',
    },
    '681t8lde': {
      'id': 'Teman',
      'en': '',
    },
    'tg3bg6sp': {
      'id': 'Beranda',
      'en': '',
    },
    'e4hacpb3': {
      'id': 'Profil',
      'en': '',
    },
    'iu23l8tz': {
      'id': 'Home',
      'en': 'home',
    },
  },
  // HomeMengikutiPage
  {
    'nplpgdtf': {
      'id': 'Ikuti',
      'en': '',
    },
    '3in8t5dd': {
      'id': 'Jelajahi',
      'en': '',
    },
    '4kzwboiv': {
      'id': 'Mengikuti',
      'en': '',
    },
    'xuj3s1ru': {
      'id': 'Teman',
      'en': '',
    },
    '0vz3zo9q': {
      'id': 'Beranda',
      'en': '',
    },
    't6eczt31': {
      'id': 'Profil',
      'en': '',
    },
    '1ddt6fht': {
      'id': 'Home',
      'en': 'home',
    },
  },
  // ProfilPage
  {
    '7t163af3': {
      'id': 'Edit',
      'en': '',
    },
    'bd94wxnq': {
      'id': '0',
      'en': '',
    },
    'jmf11o0i': {
      'id': 'Mengikuti',
      'en': '',
    },
    '3k7c0s4k': {
      'id': '0',
      'en': '',
    },
    'i1fm23zl': {
      'id': 'Penngikut',
      'en': '',
    },
    'n37cxavs': {
      'id': '0',
      'en': '',
    },
    'q0zfxq0r': {
      'id': 'Suka',
      'en': '',
    },
    '3iittkis': {
      'id': 'Beranda',
      'en': '',
    },
    'b2s3tae6': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    'da06vcf1': {
      'id': 'Home',
      'en': '',
    },
  },
  // user_profilPage
  {
    'ft2mn1al': {
      'id': '0',
      'en': '',
    },
    '32pdjgto': {
      'id': 'Mengikuti',
      'en': '',
    },
    '0oqfdvdh': {
      'id': '0',
      'en': '',
    },
    'd4hm9ry5': {
      'id': 'Penngikut',
      'en': '',
    },
    'xkldhu5k': {
      'id': '0',
      'en': '',
    },
    'snhyf2gc': {
      'id': 'Suka',
      'en': '',
    },
    '6qz8d9dn': {
      'id': 'Ikuti',
      'en': '',
    },
    'g61vqwds': {
      'id': 'Pesan',
      'en': '',
    },
    '6i17566w': {
      'id': 'Beranda',
      'en': '',
    },
    'zjidjyvn': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    '5gi2kx8f': {
      'id': 'Home',
      'en': '',
    },
  },
  // Profil_savePage
  {
    'kwkos2a4': {
      'id': 'Edit',
      'en': '',
    },
    '7kuk6hqi': {
      'id': '0',
      'en': '',
    },
    '0nzbg3rk': {
      'id': 'Mengikuti',
      'en': '',
    },
    '2q3dbqin': {
      'id': '0',
      'en': '',
    },
    'lkr2feag': {
      'id': 'Penngikut',
      'en': '',
    },
    'blfrc7mu': {
      'id': '0',
      'en': '',
    },
    'fruqdivv': {
      'id': 'Suka',
      'en': '',
    },
    'bk6cqaw1': {
      'id': 'Beranda',
      'en': '',
    },
    '03q7gb3i': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    'atythdbr': {
      'id': 'Home',
      'en': '',
    },
  },
  // Profil_LikePage
  {
    'b9nhydey': {
      'id': 'Edit',
      'en': '',
    },
    'zl7k3x0v': {
      'id': '0',
      'en': '',
    },
    'eurtzv72': {
      'id': 'Mengikuti',
      'en': '',
    },
    '6hczplib': {
      'id': '0',
      'en': '',
    },
    '8uvxdzwh': {
      'id': 'Penngikut',
      'en': '',
    },
    '839stzfy': {
      'id': '0',
      'en': '',
    },
    '5mvjoo23': {
      'id': 'Suka',
      'en': '',
    },
    'mxwre52h': {
      'id': 'Beranda',
      'en': '',
    },
    'e2240047': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    'z7kjfudk': {
      'id': 'Home',
      'en': '',
    },
  },
  // profilluserpage
  {
    'vu35k69v': {
      'id': '0',
      'en': '',
    },
    'kyvxw50q': {
      'id': 'Mengikuti',
      'en': '',
    },
    'g753do1f': {
      'id': '0',
      'en': '',
    },
    'z1lk9qtc': {
      'id': 'Penngikut',
      'en': '',
    },
    'yif35yh9': {
      'id': '0',
      'en': '',
    },
    'i7a3gs1i': {
      'id': 'Suka',
      'en': '',
    },
    'c6u0wuwt': {
      'id': 'Ikuti',
      'en': '',
    },
    'izbop3cd': {
      'id': 'Pesan',
      'en': '',
    },
    'dmgroom2': {
      'id': 'Beranda',
      'en': '',
    },
    'zi87i9c2': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    '5xvinddt': {
      'id': 'Home',
      'en': '',
    },
  },
  // profilluser2page
  {
    'jdgha7e5': {
      'id': 'name',
      'en': '',
    },
    '5fjo4hcl': {
      'id': 'username',
      'en': '',
    },
    'kl9va7n4': {
      'id': 'bio',
      'en': '',
    },
    'd7bfw8rk': {
      'id': '0',
      'en': '',
    },
    'z5lntbdd': {
      'id': 'Mengikuti',
      'en': '',
    },
    'tnqaaccq': {
      'id': '0',
      'en': '',
    },
    '1t2thavg': {
      'id': 'Penngikut',
      'en': '',
    },
    'nrjz74ci': {
      'id': '0',
      'en': '',
    },
    'vzg0id3d': {
      'id': 'Suka',
      'en': '',
    },
    '05t2e86f': {
      'id': 'Ikuti',
      'en': '',
    },
    'v9054gi1': {
      'id': 'Pesan',
      'en': '',
    },
    'dep1vtja': {
      'id': 'Beranda',
      'en': '',
    },
    'ow00aj9g': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    'f26iieoq': {
      'id': 'Home',
      'en': '',
    },
  },
  // CommentBottonSheet
  {
    '5u2x3ly7': {
      'id': 'Komentar',
      'en': '',
    },
    'vgdp2auz': {
      'id': 'Tulis Komentar',
      'en': '',
    },
  },
  // ShareButtonSheet
  {
    'gw3zurr0': {
      'id': 'Kirim Ke',
      'en': '',
    },
    'prinitwy': {
      'id': 'username ',
      'en': '',
    },
    'vgb284rk': {
      'id': 'Posting Ulang',
      'en': '',
    },
    'ulc78d40': {
      'id': 'Facebook',
      'en': '',
    },
    'k2c82cm2': {
      'id': 'WhatsApp',
      'en': '',
    },
    '9qk5moag': {
      'id': 'Messenger',
      'en': '',
    },
    'hililqba': {
      'id': 'Tidak Suka',
      'en': '',
    },
    'z4az3ssb': {
      'id': 'Unduh',
      'en': '',
    },
    'karff6lg': {
      'id': 'Hapus',
      'en': '',
    },
    'zdjymxe4': {
      'id': 'Laporkan',
      'en': '',
    },
  },
  // KeluarBottonSheet
  {
    'pj35h84o': {
      'id': 'Anda Yakin Ingin Keluar ?',
      'en': '',
    },
    '7hypu2rs': {
      'id': 'Keluar',
      'en': '',
    },
    'tt81ibff': {
      'id': 'Batalkan',
      'en': '',
    },
  },
  // ShareTemanBottonSheet
  {
    'fxyxzgpm': {
      'id': 'Kirim Ke',
      'en': '',
    },
    'bd6w0o58': {
      'id': 'username',
      'en': '',
    },
    'q52gq8k4': {
      'id': 'Bio',
      'en': '',
    },
    'ffvymkg4': {
      'id': 'Facebook',
      'en': '',
    },
    'u32uow4z': {
      'id': 'WhatsApp',
      'en': '',
    },
    'c2kj3sai': {
      'id': 'Kirim Pesan',
      'en': '',
    },
    '9or6d3bu': {
      'id': 'Blokir',
      'en': '',
    },
  },
  // soud_suaraBottonSheet
  {
    'gbinwlwi': {
      'id': 'Judul',
      'en': '',
    },
    'cbxj66hy': {
      'id': 'useername',
      'en': '',
    },
    'nk857edm': {
      'id': 'Ikuti',
      'en': '',
    },
    'zf99kmqc': {
      'id': 'Tambah Ke Favorit',
      'en': '',
    },
    'xgp0krq7': {
      'id': 'Gunakan Suara',
      'en': '',
    },
  },
  // sTemanBottonShee
  {
    '51lf01tm': {
      'id': 'Kirim Ke',
      'en': '',
    },
    'k784kz1w': {
      'id': 'Facebook',
      'en': '',
    },
    'ftbhju2c': {
      'id': 'WhatsApp',
      'en': '',
    },
    '0zgnihvs': {
      'id': 'Kirim Pesan',
      'en': '',
    },
    '4vy3dldt': {
      'id': 'Blokir',
      'en': '',
    },
  },
  // kirimButtonSheet
  {
    'qabnrh6o': {
      'id': 'Tulis Pesan',
      'en': '',
    },
    '74cu7ffk': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // UploadBotttonSheet
  {
    '6hx86sw0': {
      'id': 'user',
      'en': '',
    },
    '4lpm30y4': {
      'id': 'username',
      'en': '',
    },
    'e8c1fujq': {
      'id': 'bio',
      'en': '',
    },
    'ag1628n8': {
      'id': 'Edit',
      'en': '',
    },
    'rfq652hj': {
      'id': '0',
      'en': '',
    },
    'ndt2sgpq': {
      'id': 'Mengikuti',
      'en': '',
    },
    '85xgqhfk': {
      'id': '0',
      'en': '',
    },
    'zk3r320s': {
      'id': 'Pengiikut',
      'en': '',
    },
    'nntry6kz': {
      'id': '0',
      'en': '',
    },
    '75rpsqlc': {
      'id': 'Suka',
      'en': '',
    },
    'ag6mdv51': {
      'id': 'Upload Video',
      'en': '',
    },
  },
  // CariBoottonSheet
  {
    'h35f7dks': {
      'id': 'kirim  Ke',
      'en': '',
    },
    'zp6di5cb': {
      'id': 'Cari Teman',
      'en': '',
    },
    '72jzx9dz': {
      'id': 'Cari',
      'en': '',
    },
    '94oz19px': {
      'id': 'username',
      'en': '',
    },
    'fpdg29h6': {
      'id': 'Bio',
      'en': '',
    },
  },
  // kirimuserButtonSheet
  {
    'xtl3kscz': {
      'id': 'Tulis Pesan',
      'en': '',
    },
    'ythua5cp': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // CartemaniBoottonSheet
  {
    'tf1w77lv': {
      'id': 'kirim  Ke',
      'en': '',
    },
    'mv7rs0z8': {
      'id': 'Cari Teman',
      'en': '',
    },
    '2rweo0r9': {
      'id': 'Cari',
      'en': '',
    },
    'gjk79dxb': {
      'id': 'username',
      'en': '',
    },
    'onzs3126': {
      'id': 'Bio',
      'en': '',
    },
  },
  // IconBottonSheet
  {
    'f1mrrq0w': {
      'id': 'Kotak Masuk',
      'en': '',
    },
    'kk8tl1ih': {
      'id': 'Setting',
      'en': '',
    },
    'axft7p6v': {
      'id': 'Search',
      'en': '',
    },
  },
  // hapusBottonSheet
  {
    'nohxl7sj': {
      'id': 'Yakin Mau Hapus Postingan ini',
      'en': '',
    },
    'g3onsefc': {
      'id': 'Hapus',
      'en': '',
    },
    'v1eis48l': {
      'id': 'Batalkan',
      'en': '',
    },
  },
  // laporkanBottonSheet
  {
    '95nxotze': {
      'id': 'Silahkan Pilih alasan',
      'en': '',
    },
    '78lnu6pm': {
      'id': 'Kekerasan & Pelecehan',
      'en': '',
    },
    'cczg8y0d': {
      'id': 'Bunuh diri dan melukai diri sendiri',
      'en': '',
    },
    '99hhu21f': {
      'id': 'konten seksual dan ketelanjangan',
      'en': '',
    },
    'o963t6y5': {
      'id': 'penipuan dan spam',
      'en': '',
    },
  },
  // alasanBottonSheet
  {
    '1i10lgpz': {
      'id': 'Silahkan Pilih Alasan',
      'en': '',
    },
    'ylztpe80': {
      'id': 'Pelecehan terhadap anak',
      'en': '',
    },
    's8oisn7w': {
      'id': 'Berusia di bawah 18 tahun',
      'en': '',
    },
    '7pkv4q5p': {
      'id': 'kekerasan fisik dan ancaman kekerasan',
      'en': '',
    },
  },
  // pelapor11bottonSheet
  {
    'hi9yh9bb': {
      'id': 'Laporkan ',
      'en': '',
    },
    'aakdlm6o': {
      'id': 'Pelecehan terhadap anak berusia di bawah 18 tahun',
      'en': '',
    },
    'wxl6zfzh': {
      'id':
          '. menampilkan perilaku yang tidak pantas, berbahaya, dan melanggar kebijakan perlindungan anak. Mohon segera ditindaklanjuti.',
      'en': '',
    },
    'l5r0csvb': {
      'id':
          '. Saya melaporkan konten ini karena diduga mengeksploitasi dan melecehkan anak di bawah 18 tahun.\nKonten tersebut berpotensi membahayakan anak secara fisik dan psikologis serta melanggar aturan platform.',
      'en': '',
    },
    'n6qikbth': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // suksesBottonSheet
  {
    'bsjc0z39': {
      'id': 'Terimakasih telah ',
      'en': '',
    },
    'sfqrqqj0': {
      'id': 'Melaporkan',
      'en': '',
    },
    'wy2u1crd': {
      'id': 'kami akan meninjau laporan anda',
      'en': '',
    },
    '5lkjljld': {
      'id':
          'dan mengambil tindakan jika ada pelanggaran Panduan Komunitas kami.anda juga dapat',
      'en': '',
    },
    'u5ctqx51': {
      'id': ' melihat riwayat laporan di Pengaturan & Privasi.',
      'en': '',
    },
    '20hupnpq': {
      'id': 'Selesai',
      'en': '',
    },
    'ndtsddcc': {
      'id': 'Lihat Laporan anda',
      'en': '',
    },
  },
  // kekerasanbottonsheet
  {
    'gb9z4psf': {
      'id': 'Laporkan',
      'en': '',
    },
    '27by8owv': {
      'id': 'Kekerasan fisik dan ancaman kekerasan',
      'en': '',
    },
    'yf24db0n': {
      'id':
          '. Video ini mengandung ancaman dan kekerasan fisik yang ditampilkan secara tidak pantas dan berpotensi menimbulkan ketakutan serta menormalisasi kekerasan.',
      'en': '',
    },
    'ocse7yn6': {
      'id':
          '. Konten ini mempromosikan atau memperlihatkan kekerasan fisik dan ancaman kekerasan, sehingga tidak sesuai dengan kebijakan platform.',
      'en': '',
    },
    'kq94e688': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // dirisendiribottonSheet
  {
    'zbqygfyb': {
      'id': 'Laporkan',
      'en': '',
    },
    '0gtrmpfy': {
      'id': 'Bunuh diri dan melukai diri sendirl',
      'en': '',
    },
    'qiywmksh': {
      'id':
          '. Video ini memperlihatkan atau membahas tindakan menyakiti diri sendiri yang tidak pantas dan berpotensi mendorong perilaku berbahaya.',
      'en': '',
    },
    'ldiw5dkh': {
      'id':
          '. Terdapat ajakan atau normalisasi tindakan menyakiti diri sendiri yang berisiko dan dapat berdampak buruk bagi pengguna.',
      'en': '',
    },
    'hjjmqc5p': {
      'id': 'Button',
      'en': '',
    },
  },
  // melukaidiribottonsheet
  {
    'gk6qvhb4': {
      'id': 'Laporkan',
      'en': '',
    },
    'nt0enaz0': {
      'id': 'Bunuh diri dan melukai diri sendiri',
      'en': '',
    },
    'd2lj074e': {
      'id':
          ' . Video ini menampilkan atau membahas tindakan bunuh diri/melukai diri sendiri sehingga tidak sesuai dengan pedoman komunitas dan berpotensi berdampak buruk bagi penonton.',
      'en': '',
    },
    'ebrot7qx': {
      'id':
          ' . Konten ini mempromosikan atau menormalisasi perilaku bunuh diri dan melukai diri sendiri. Mohon ditindak karena berbahaya bagi kesehatan mental pengguna.',
      'en': '',
    },
    'cw543kw1': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // layananbottonsheeet
  {
    '33gsb1e2': {
      'id': 'Laporkan',
      'en': '',
    },
    'p5rr3jzv': {
      'id': 'Ajakan seksual dewasa dan ketelanjangan',
      'en': '',
    },
    '9xcx0wcd': {
      'id':
          '. Konten ini mengandung ajakan seksual dewasa serta menampilkan ketelanjangan yang tidak pantas dan melanggar pedoman komunitas.',
      'en': '',
    },
    '7y25h369': {
      'id':
          ' . Video ini berisi unsur seksual dewasa dan ketelanjangan eksplisit yang tidak sesuai dengan kebijakan platform.',
      'en': '',
    },
    'keu7ivzo': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // scambottonsheet
  {
    'q04wyo82': {
      'id': 'Laporkan',
      'en': '',
    },
    'hzcg57u6': {
      'id': 'Penipuan dan scam',
      'en': '',
    },
    'u1uusbay': {
      'id':
          ' . Video ini mengandung indikasi penipuan. Terdapat ajakan atau informasi menyesatkan yang berpotensi menyebabkan kerugian dan termasuk scam.',
      'en': '',
    },
    '0fmtvkrp': {
      'id':
          ' . Konten ini mengandung unsur penipuan/scam. Pelaku diduga menipu pengguna dengan informasi palsu dan berpotensi merugikan secara finansial.',
      'en': '',
    },
    'fthw9a64': {
      'id': 'Kirim',
      'en': '',
    },
  },
  // Miscellaneous
  {
    'c2l76ifc': {
      'id':
          'Untuk mengambil foto atau video, aplikasi memerlukan izin mengakses kamera.',
      'en':
          'This app needs permission to access your camera to take photos or videos.',
    },
    '7jsng79m': {
      'id':
          'Untuk merekam suara pada video, aplikasi memerlukan izin mengakses mikrofon.',
      'en':
          'Untuk merekam suara pada video, aplikasi memerlukan izin mengakses mikrofon.English',
    },
    'ker3kx0d': {
      'id':
          'Untuk memilih atau menyimpan foto dan video, aplikasi memerlukan izin mengakses galeri.',
      'en':
          'This app needs permission to access your photo library to select or save photos and videos.',
    },
    '5sxhlob9': {
      'id':
          'Aplikasi memerlukan izin mengakses kontak untuk membantu Anda menemukan teman.',
      'en':
          'This app needs permission to access your contacts to help you find friends.',
    },
    'scz404z7': {
      'id':
          'Aplikasi memerlukan izin lokasi untuk meningkatkan pengalaman dan fitur berbasis lokasi.',
      'en':
          'This app needs access to your location to improve location-based features.',
    },
    'vq6d80ox': {
      'id':
          'Izinkan notifikasi agar Anda tidak ketinggalan informasi dan aktivitas terbaru.',
      'en':
          'Allow notifications so you don’t miss important updates and activities.',
    },
    'bijnmqgi': {
      'id':
          'Aplikasi memerlukan izin mengakses kalender untuk mengelola acara dan pengingat.',
      'en':
          'This app needs permission to access your calendar to manage events and reminders.',
    },
    '3rwsx3d3': {
      'id':
          'Aplikasi menggunakan biometrik untuk keamanan dan akses cepat ke akun Anda.',
      'en':
          'This app uses biometric authentication for security and quick access to your account.',
    },
    'o6pf6bo3': {
      'id':
          'Aplikasi memerlukan izin Bluetooth untuk terhubung dengan perangkat terdekat.',
      'en':
          'This app needs Bluetooth permission to connect with nearby devices.',
    },
    'd5hfa0hf': {
      'id': '',
      'en': 'Authentication failed. Please try again.',
    },
    '8ttgb4nt': {
      'id': '',
      'en': 'Password reset email has been sent.',
    },
    'sv0m21fw': {
      'id': '',
      'en': 'Too many attempts. Please try again later.',
    },
    'ubm58ker': {
      'id': '',
      'en': '',
    },
    'gdm5uj8l': {
      'id': '',
      'en': '',
    },
    'htc0rlma': {
      'id': '',
      'en': 'Email or password is incorrect.',
    },
    't1evlxyp': {
      'id': '',
      'en':
          'You have not signed in recently. Please sign in again before deleting your account.',
    },
    'jh2hcgkm': {
      'id': '',
      'en': '',
    },
    'uxqbwiz0': {
      'id': '',
      'en': 'Email change confirmation email sent.',
    },
    'k0yezpn1': {
      'id': '',
      'en': 'This email is already used by another account.',
    },
    '66196soi': {
      'id': '',
      'en': 'Email or password is incorrect.',
    },
    'diaq8bl9': {
      'id': '',
      'en': '',
    },
    'l5ti9eh9': {
      'id': '',
      'en': '',
    },
    'wsbivhxg': {
      'id': '',
      'en': '',
    },
    '5ueuu8ap': {
      'id': '',
      'en': '',
    },
    'btnj8nf8': {
      'id': '',
      'en': '',
    },
    '2pvvsa49': {
      'id': '',
      'en': '',
    },
    'ewdb1nnh': {
      'id': '',
      'en': '',
    },
    'kiru1ooq': {
      'id': 'photo',
      'en': '',
    },
    'vizxfvb3': {
      'id': 'video',
      'en': '',
    },
    'y2obmyko': {
      'id': 'photo',
      'en': '',
    },
    'bqzo1c6v': {
      'id': '',
      'en': '',
    },
    '7ifrasfv': {
      'id': '',
      'en': '',
    },
    'g8gyytru': {
      'id': '',
      'en': '',
    },
    'z41fqnym': {
      'id': '',
      'en': '',
    },
  },
].reduce((a, b) => a..addAll(b));
