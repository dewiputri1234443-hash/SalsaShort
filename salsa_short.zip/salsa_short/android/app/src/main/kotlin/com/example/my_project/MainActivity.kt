package com.mycompany.salsashort

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
